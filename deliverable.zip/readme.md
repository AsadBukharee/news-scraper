# **Components**
1. FastApi App to serve data through APIs
2. Redis:  Works as a Queue to hold latest data and it isalso used by celery.
3. Celery: celery worker for background tasks.
4. Core: core module to do the heavy scraping tasks.
5. Subprocess: to execute celery worker as an independent process from fastapi.

# To DOs
1. keep your custom values in .env file
2. mention the time interval to tell the scraper to scrap after INTERVAL (default value is 30 minutes) minutes


# How Does It Work


