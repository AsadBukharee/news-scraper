from scraper import scrape_news
if __name__=="__main__":
    scrape_news()